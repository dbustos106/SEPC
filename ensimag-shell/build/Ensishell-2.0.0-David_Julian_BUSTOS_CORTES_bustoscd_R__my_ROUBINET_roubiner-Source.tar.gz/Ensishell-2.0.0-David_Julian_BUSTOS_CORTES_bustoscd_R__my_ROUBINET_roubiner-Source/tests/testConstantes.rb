#!/bin/ruby

PROMPT=/^ensishell>/
DELAI=1
COMMANDESHELL="./ensishell"
# PROMPT=/^.*\$/
# DELAI=1
# COMMANDESHELL="sh"
